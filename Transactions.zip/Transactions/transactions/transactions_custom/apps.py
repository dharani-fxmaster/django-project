from django.apps import AppConfig


class CustomTransactionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transactions_custom'
